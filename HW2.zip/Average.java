import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Average {

     // references to the beginning and end of the list
     static Node head = null;
     static Node tail = null;


     // Node contains an int called data and a reference to a Node called next
     static class Node {
          final int data;
          Node next;

          // constructor initially makes the node take on the data
          // and be free-floating, only being
          // attached to the list in the right place
          // at the time of assignment after the creation of this object
          public Node(int data) {
               this.data = data;
               this.next = null;
          }
     }

     // follow the path to a file and read it
     // numbers are whitespace-delimited
     // put each new number (there might be duplicates in a new node of a linked list
     // when the list has been created, return its head
     Node readIO(String filePath) throws IOException {

          // setting up I/O
          File file = new File(filePath);
          // wrapping a FileReader with a BufferedReader makes efficiency gains
          BufferedReader reader = new BufferedReader(new FileReader(file));

          // this will be what gets read and put into the list
          String line;

          while ((line = reader.readLine()) != null) {
               // Split the line into individual numbers based on spaces and/or line-breaks
               String[] numbers = line.trim().split("\\s+");

               // Iterate through the numbers and add them to the list
               for (String strNum : numbers) {
                    // Convert the string to an int
                    int num = Integer.parseInt(strNum);
                    // If the list is empty, the new element is both the front and the back of the list
                    if (head == null) {
                         head = new Node(num);
                         tail = head;
                    }
                    // Otherwise, add the new element to the back of the list
                    else {
                         tail.next = new Node(num);
                         tail = tail.next;
                    }
               }
          }
          // return a reference to the front of the list
          return head;
     }

     // recursive linear search
     boolean averageOfListIsInList(Node startFromHere, int average) {
          // the average is not in a null list
          if (startFromHere == null) {
               return false;
          }

          // if the list isn't null, check if the current value matches, or search through
          // the remainder of the list to see if it's there
          return startFromHere.data == average || averageOfListIsInList(startFromHere.next, average);
     }

     boolean averageOfFirstNIsInList(Node startFromHere, int averageOfFirstN){
          // the average is not in a null list
          if (startFromHere == null) {
               return false;
          }

          // if the list isn't null, check if the current value matches, or search through
          // the remainder of the list to see if it's there
          return startFromHere.data == averageOfFirstN || averageOfFirstNIsInList(startFromHere.next, averageOfFirstN);
     }

     // calculate the sum recursively
     private int calculateSum(Node current) {
          // the sum of a null list is 0
          // but if the list is not null, then
          // the sum of a list is the current element plus the sum of the rest of the list
          return current == null ? 0 : current.data + calculateSum(current.next);
     }


     // calculate the count recursively
     private int calculateCount(Node current) {
          // there are no elements in a null list
          // but otherwise if the list is not null, then
          // the size of a list is 1 plus the size of the rest of the list
          return current == null ? 0 : 1 + calculateCount(current.next);
     }

     private double calculateAverageOfFirstN(Node current, int n) {
          if (current == null || n == 0) {
               return 0;
          } else if (n == 1) {
               return current.data; // Base case: only one element left
          } else {
               // Recursive case: add the current node's data to the sum and continue with the rest
               return (current.data + calculateAverageOfFirstN(current.next, n - 1) * (n - 1)) / n;
          }
     }

     public static void main(String[] args) throws IOException {
          Average average = new Average();
          // readIO takes in a String which is the path to the file containing the numbers and
          // returns the head of the list created from the filePath
          head = average.readIO(args[0]);
          // when the list is blank, return no
          if (head == null) {
               System.out.println("No");
               return;
          }
          // if the list isn't blank, continue through here
          int averageResult = average.calculateSum(head) / average.calculateCount(head);
          // if the program finds the value searching recursively from the head, then output yes
          if (average.averageOfListIsInList(head, averageResult)) {
               System.out.println("Yes");
          }
          // if it doesn't find it, output no
          else {
               System.out.println("No");
          }
     }
}